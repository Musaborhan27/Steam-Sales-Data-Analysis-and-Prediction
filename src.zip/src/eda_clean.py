import pandas as pd
import os

def clean_data(input_csv, output_csv):
    """
    Read raw CSV, drop missing, convert owners range to minimum,
    filter positives, and save cleaned CSV.
    """
    df = pd.read_csv(input_csv)
    df = df.dropna(subset=['name', 'price', 'initial_price', 'owners'])

    def parse_owners(o):
        try:
            return int(o.split('..')[0].replace(',', '').strip())
        except:
            return None
    df['owners'] = df['owners'].apply(parse_owners)

    df = df[(df['initial_price'] > 0) &
            (df['price'] > 0) &
            (df['owners'].notnull())]

    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    df.to_csv(output_csv, index=False)
    print(f"✅ Cleaned data saved to {output_csv} (shape={df.shape})")
    return df

if __name__ == '__main__':
    here = os.path.dirname(__file__)
    clean_data(
        os.path.join(here, '..', 'data', 'steamspy_top100.csv'),
        os.path.join(here, '..', 'cleaned_data', 'steamspy_clean.csv')
    )
