import psycopg2
import os
import configparser

def get_db_params():
    cfg = configparser.ConfigParser()
    cfg.read(os.path.join(os.path.dirname(__file__), '..', 'config.ini'))
    p = cfg['postgres']
    return {
        'host':     p.get('host', 'localhost'),
        'port':     p.get('port', '5432'),
        'dbname':   p['dbname'],
        'user':     p['user'],
        'password': p['password']
    }

def load_csv_to_db(csv_path, db_params):
    conn = psycopg2.connect(**db_params)
    cur  = conn.cursor()

    # Create table
    ddl = open(os.path.join(os.path.dirname(__file__), '..', 'create_tables.sql')).read()
    cur.execute(ddl)
    conn.commit()

    # Clear existing data
    cur.execute('TRUNCATE TABLE steam_sales;')
    conn.commit()

    # Bulk load
    with open(csv_path, 'r', encoding='utf-8') as f:
        next(f)
        cur.copy_expert(
            "COPY steam_sales(appid,name,release_date,owners,initial_price,price,discount) "
            "FROM STDIN WITH CSV HEADER",
            f
        )
    conn.commit()

    # Compute derived columns
    cur.execute("""
        UPDATE steam_sales
        SET
            price_ratio   = CASE WHEN initial_price <> 0 THEN price / initial_price END,
            is_discounted = discount > 0,
            release_age   = EXTRACT(YEAR FROM age(CURRENT_DATE, release_date))
    """)
    conn.commit()

    cur.close()
    conn.close()
    print("✅ Data loaded into database.")

if __name__ == '__main__':
    dp = get_db_params()
    load_csv_to_db(
        os.path.join(os.path.dirname(__file__), '..', 'cleaned_data', 'steamspy_clean.csv'),
        dp
    )
