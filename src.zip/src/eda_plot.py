import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns

def plot_distributions(clean_csv):
    """
    Generate and save histograms for price and discount.
    """
    df = pd.read_csv(clean_csv)
    out_dir = os.path.dirname(clean_csv)

    plt.figure()
    sns.histplot(df['price'], bins=30)
    plt.title('Price Distribution')
    plt.xlabel('Price')
    plt.ylabel('Count')
    plt.savefig(os.path.join(out_dir, 'price_distribution.png'))
    plt.close()

    plt.figure()
    sns.histplot(df['discount'], bins=30)
    plt.title('Discount Distribution')
    plt.xlabel('Discount (%)')
    plt.ylabel('Count')
    plt.savefig(os.path.join(out_dir, 'discount_distribution.png'))
    plt.close()

    print(f"✅ Plots saved to {out_dir}")

if __name__ == '__main__':
    here = os.path.dirname(__file__)
    plot_distributions(os.path.join(here, '..', 'cleaned_data', 'steamspy_clean.csv'))
