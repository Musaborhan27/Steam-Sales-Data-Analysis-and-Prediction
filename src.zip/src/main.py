# steam_project/src/main.py

import os
from scrape import fetch_data
from eda_clean import clean_data
from eda_plot import plot_distributions
from eda_ml import prepare_ml_dataset
from model_train import train_models
from model_improved import improve_model
from ml_analysis import analyze_models
from load_to_db import load_csv_to_db, get_db_params
from query_db import run_sample_queries

def main():
    root = os.path.dirname(__file__)

    # 1. Fetch raw data
    data_dir = os.path.join(root, '..', 'data')
    os.makedirs(data_dir, exist_ok=True)
    raw_csv = os.path.join(data_dir, 'steamspy_top100.csv')
    fetch_data(raw_csv)

    # 2. Clean data
    clean_dir = os.path.join(root, '..', 'cleaned_data')
    os.makedirs(clean_dir, exist_ok=True)
    clean_csv = os.path.join(clean_dir, 'steamspy_clean.csv')
    clean_data(raw_csv, clean_csv)

    # 3. Plot distributions
    plot_distributions(clean_csv)

    # 4. Prepare ML dataset
    ml_dir = os.path.join(root, '..', 'ml_output')
    os.makedirs(ml_dir, exist_ok=True)
    ml_csv = os.path.join(ml_dir, 'ml_dataset.csv')
    prepare_ml_dataset(clean_csv, ml_csv)

    # 5. Train baseline models
    train_models(ml_csv)

    # 6. Improve model
    improve_model()

    # 7. Compare models
    analyze_models()

    # 8. Load to database
    db_params = get_db_params()
    load_csv_to_db(clean_csv, db_params)

    # 9. Run sample SQL queries
    run_sample_queries(db_params)

if __name__ == '__main__':
    main()
