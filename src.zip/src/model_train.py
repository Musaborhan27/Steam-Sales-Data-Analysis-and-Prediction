import os
import pandas as pd
import numpy as np
import joblib
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

def train_models(input_csv):
    """
    Train LR and RF, save metrics and artifacts.
    """
    df = pd.read_csv(input_csv)
    X = df[['owners', 'initial_price', 'discount']]
    y = df['price']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Linear Regression
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_pred_lr = lr.predict(X_test)

    # Random Forest
    rf = RandomForestRegressor(random_state=42)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)

    rmse_lr = np.sqrt(mean_squared_error(y_test, y_pred_lr))
    r2_lr   = r2_score(y_test, y_pred_lr)
    rmse_rf = np.sqrt(mean_squared_error(y_test, y_pred_rf))
    r2_rf   = r2_score(y_test, y_pred_rf)

    print(f"➡️  LR RMSE={rmse_lr:.2f}, R²={r2_lr:.3f}")
    print(f"➡️  RF RMSE={rmse_rf:.2f}, R²={r2_rf:.3f}")

    out_dir = os.path.join(os.path.dirname(__file__), '..', 'ml_output')
    os.makedirs(out_dir, exist_ok=True)

    pd.DataFrame({
        'y_test':  y_test.values,
        'LR_pred': y_pred_lr,
        'RF_pred': y_pred_rf
    }).to_csv(
        os.path.join(out_dir, 'predictions_comparison.csv'),
        index=False
    )

    joblib.dump(lr, os.path.join(out_dir, 'linear_model.pkl'))
    joblib.dump(rf, os.path.join(out_dir, 'random_forest.pkl'))

    fig, ax = plt.subplots()
    ax.barh(X.columns, rf.feature_importances_)
    ax.set_title('Random Forest Feature Importance')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, 'rf_feature_importance.png'))
    plt.close()

    print(f"✅ Baseline artifacts saved to {out_dir}")

if __name__ == '__main__':
    here = os.path.dirname(__file__)
    train_models(os.path.join(here, '..', 'ml_output', 'ml_dataset.csv'))
