import os
import pandas as pd
from sklearn.metrics import mean_squared_error, r2_score
import math

def analyze_models():
    """
    Compare baseline and improved model performance.
    """
    # Baseline
    base_csv = os.path.join(os.path.dirname(__file__), '..', 'ml_output', 'predictions_comparison.csv')
    df_base  = pd.read_csv(base_csv)
    y_true   = df_base['y_test']
    lr_pred  = df_base['LR_pred']
    rf_pred  = df_base['RF_pred']

    rmse_lr = math.sqrt(mean_squared_error(y_true, lr_pred))
    rmse_rf = math.sqrt(mean_squared_error(y_true, rf_pred))
    r2_lr   = r2_score(y_true, lr_pred)
    r2_rf   = r2_score(y_true, rf_pred)

    # Improved
    imp_csv = os.path.join(os.path.dirname(__file__), '..', 'ml_output_improved', 'predictions_improved.csv')
    df_imp  = pd.read_csv(imp_csv)
    y_imp   = df_imp['y_test']
    rf_imp  = df_imp['RF_pred']

    rmse_imp = math.sqrt(mean_squared_error(y_imp, rf_imp))
    r2_imp   = r2_score(y_imp, rf_imp)

    print("\n— MODEL COMPARISON —")
    print(f"Baseline LR    RMSE: {rmse_lr:.2f}, R²: {r2_lr:.3f}")
    print(f"Baseline RF    RMSE: {rmse_rf:.2f}, R²: {r2_rf:.3f}")
    print(f"Improved RF    RMSE: {rmse_imp:.2f}, R²: {r2_imp:.3f}")

if __name__ == '__main__':
    analyze_models()
