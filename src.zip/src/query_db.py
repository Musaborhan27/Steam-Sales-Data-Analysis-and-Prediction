import psycopg2

def run_sample_queries(db_params):
    conn = psycopg2.connect(**db_params)
    cur  = conn.cursor()

    print("\n--- Top 5 Discounted Games ---")
    cur.execute("SELECT name, discount FROM steam_sales ORDER BY discount DESC LIMIT 5;")
    for row in cur.fetchall():
        print(row)

    print("\n--- Average Price by Release Year ---")
    cur.execute("""
        SELECT EXTRACT(YEAR FROM release_date) AS year,
               ROUND(AVG(price),2)
          FROM steam_sales
         GROUP BY year
         ORDER BY year;
    """)
    for row in cur.fetchall():
        print(row)

    cur.close()
    conn.close()
