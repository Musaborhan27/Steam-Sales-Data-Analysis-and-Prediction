import pandas as pd
import os

def prepare_ml_dataset(input_csv, output_csv):
    """
    Read cleaned CSV, coerce types, drop NA, and save ML-ready CSV
    """
    df = pd.read_csv(input_csv)
    df['owners']   = pd.to_numeric(df['owners'], errors='coerce')
    df['discount'] = df['discount'].fillna(0)
    df = df.dropna(subset=['owners', 'initial_price', 'price'])

    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    df.to_csv(output_csv, index=False)
    print(f"🔢 ML dataset saved to {output_csv}")
    return df

if __name__ == '__main__':
    here = os.path.dirname(__file__)
    prepare_ml_dataset(
        os.path.join(here, '..', 'cleaned_data', 'steamspy_clean.csv'),
        os.path.join(here, '..', 'ml_output', 'ml_dataset.csv')
    )
