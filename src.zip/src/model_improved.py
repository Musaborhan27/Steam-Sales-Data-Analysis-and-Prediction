import os
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import math

def improve_model():
    """
    Grid-search a better RF, evaluate, and save improved artifacts.
    """
    here   = os.path.dirname(__file__)
    ml_csv = os.path.join(here, '..', 'ml_output', 'ml_dataset.csv')
    df     = pd.read_csv(ml_csv)

    X = df[['owners', 'initial_price', 'discount']]
    y = df['price']
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

    grid = GridSearchCV(
        RandomForestRegressor(random_state=42),
        {'n_estimators': [100,200], 'max_depth': [None,10,20]},
        cv=5, n_jobs=-1
    )
    grid.fit(X_tr, y_tr)
    best = grid.best_estimator_

    y_pred = best.predict(X_te)
    rmse    = math.sqrt(mean_squared_error(y_te, y_pred))
    r2      = r2_score(y_te, y_pred)

    print(f"✅ Best RF params: {grid.best_params_}")
    print(f"➡️  Improved RF RMSE={rmse:.2f}, R²={r2:.3f}")

    out_dir = os.path.join(here, '..', 'ml_output_improved')
    os.makedirs(out_dir, exist_ok=True)

    joblib.dump(best, os.path.join(out_dir, 'rf_improved.pkl'))
    pd.DataFrame({'y_test': y_te.values, 'RF_pred': y_pred}) \
        .to_csv(os.path.join(out_dir, 'predictions_improved.csv'), index=False)

    fig, ax = plt.subplots()
    ax.barh(X.columns, best.feature_importances_)
    ax.set_title('Improved RF Feature Importance')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, 'rf_feature_importance_improved.png'))
    plt.close()

    print(f"✅ Improved artifacts saved to {out_dir}")

if __name__ == '__main__':
    improve_model()
