import requests
import pandas as pd
import os

def fetch_data(output_csv):
    """
    Fetch top-100 games from SteamSpy API and save to CSV.
    """
    url = 'https://steamspy.com/api.php?request=top100in2weeks'
    resp = requests.get(url)
    resp.raise_for_status()
    data = resp.json()

    records = []
    for appid, info in data.items():
        records.append({
            'appid':        int(appid),
            'name':         info.get('name'),
            'release_date': info.get('release_date'),
            'owners':       info.get('owners'),
            'initial_price': int(info.get('initialprice', 0)) / 100,
            'price':        int(info.get('price', 0)) / 100,
            'discount':     info.get('discount', 0)
        })
    df = pd.DataFrame(records)
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    df.to_csv(output_csv, index=False)
    print(f"✅ Data fetched and saved to {output_csv}")

if __name__ == '__main__':
    here = os.path.dirname(__file__)
    fetch_data(os.path.join(here, '..', 'data', 'steamspy_top100.csv'))
